
-- Fix overly permissive insert policy
DROP POLICY IF EXISTS "Service role can insert events" ON public.events;

-- Replace with proper policy: authenticated users can create events (with or without user_id)
DROP POLICY IF EXISTS "Users can create events" ON public.events;
CREATE POLICY "Users can create events"
  ON public.events FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL AND (user_id IS NULL OR auth.uid() = user_id));
