
-- Allow nullable user_id temporarily is not ideal. Instead, create a system seed approach.
-- We'll drop the FK constraint, insert seed data, then re-add it.
-- Actually, let's just make user_id nullable for events so admins/system can create events
ALTER TABLE public.events ALTER COLUMN user_id DROP NOT NULL;

-- Update RLS to allow viewing events even without user_id
DROP POLICY IF EXISTS "Authenticated users can view events" ON public.events;
CREATE POLICY "Authenticated users can view events"
  ON public.events FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- Allow service role inserts (for seeding)
CREATE POLICY "Service role can insert events"
  ON public.events FOR INSERT
  WITH CHECK (true);
