import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Ticket, Mail, Lock, CalendarDays, Music, Users, Star } from "lucide-react";
import { toast } from "sonner";
import heroBg from "@/assets/hero-concert.jpg";

const Landing = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (isLogin) {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        toast.error(error.message);
      } else {
        toast.success("Welcome back!");
        navigate("/home");
      }
    } else {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: window.location.origin },
      });
      if (error) {
        toast.error(error.message);
      } else {
        toast.success("Check your email to confirm your account!");
      }
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img src={heroBg} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/90 to-background/50" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/60" />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Nav */}
        <header className="container flex items-center justify-between py-6">
          <div className="flex items-center gap-2">
            <Ticket className="h-7 w-7 text-primary" />
            <span className="font-display text-2xl font-bold text-foreground">
              Even<span className="text-primary">tix</span>
            </span>
          </div>
        </header>

        {/* Content */}
        <div className="container flex-1 flex items-center">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 w-full items-center py-10">
            {/* Left - Hero text */}
            <div className="space-y-6 animate-fade-in-up">
              <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm text-primary">
                <CalendarDays className="h-4 w-4" />
                <span>Discover events near you</span>
              </div>

              <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-[1.1]">
                Explore{" "}
                <span className="text-gradient">Unforgettable</span>{" "}
                Events
              </h1>

              <p className="text-lg text-muted-foreground max-w-lg">
                Browse concerts, conferences, sports, and more. Create your own events, 
                check availability, and book tickets instantly with secure payments.
              </p>

              {/* Features */}
              <div className="grid grid-cols-3 gap-4 pt-4">
                {[
                  { icon: Music, label: "Live Events", sub: "Concerts & more" },
                  { icon: Users, label: "Community", sub: "Join thousands" },
                  { icon: Star, label: "Top Rated", sub: "98% satisfaction" },
                ].map((item) => (
                  <div key={item.label} className="space-y-1">
                    <item.icon className="h-5 w-5 text-primary" />
                    <p className="font-display text-sm font-semibold text-foreground">{item.label}</p>
                    <p className="text-xs text-muted-foreground">{item.sub}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Right - Auth card */}
            <div className="w-full max-w-md mx-auto lg:mx-0 lg:ml-auto animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              <div className="rounded-xl bg-card/80 backdrop-blur-xl border border-border p-8 space-y-6 card-shadow">
                <div className="text-center space-y-1">
                  <h2 className="font-display text-2xl font-bold text-foreground">
                    {isLogin ? "Welcome Back" : "Join Eventix"}
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    {isLogin ? "Sign in to continue" : "Create your account"}
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-foreground">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="email"
                        type="email"
                        placeholder="you@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="pl-10 bg-secondary border-border"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-foreground">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="password"
                        type="password"
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="pl-10 bg-secondary border-border"
                        required
                        minLength={6}
                      />
                    </div>
                  </div>

                  <Button type="submit" className="w-full glow-primary" size="lg" disabled={loading}>
                    {loading ? "Please wait..." : isLogin ? "Sign In" : "Create Account"}
                  </Button>
                </form>

                <p className="text-center text-sm text-muted-foreground">
                  {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
                  <button
                    onClick={() => setIsLogin(!isLogin)}
                    className="text-primary hover:underline font-medium"
                  >
                    {isLogin ? "Sign Up" : "Sign In"}
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Landing;
