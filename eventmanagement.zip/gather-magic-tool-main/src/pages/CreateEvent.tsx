import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const eventTypes = [
  { value: "concert", label: "Concert" },
  { value: "conference", label: "Conference" },
  { value: "sports", label: "Sports" },
  { value: "theater", label: "Theater" },
  { value: "festival", label: "Festival" },
  { value: "workshop", label: "Workshop" },
];

const CreateEvent = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    event_type: "",
    price: "",
    total_tickets: "",
    date: "",
    time: "7:00 PM",
    venue: "",
    city: "",
    image_url: "",
  });

  const handleChange = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    const { error } = await supabase.from("events").insert({
      user_id: user.id,
      title: form.title.trim(),
      description: form.description.trim() || null,
      event_type: form.event_type,
      price: parseFloat(form.price) || 0,
      total_tickets: parseInt(form.total_tickets) || 100,
      available_tickets: parseInt(form.total_tickets) || 100,
      date: form.date,
      time: form.time,
      venue: form.venue.trim(),
      city: form.city.trim(),
      image_url: form.image_url.trim() || null,
    });

    if (error) {
      toast.error("Failed to create event: " + error.message);
    } else {
      toast.success("Event created successfully!");
      navigate("/home");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-24 pb-20">
        <div className="container max-w-2xl">
          <Link
            to="/home"
            className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-6 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Events
          </Link>

          <h1 className="font-display text-3xl font-bold text-foreground mb-2">
            Create Event
          </h1>
          <p className="text-muted-foreground mb-8">
            Fill in the details to list your event on Eventix
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="rounded-lg bg-card border border-border p-6 space-y-5 card-shadow">
              <div className="space-y-2">
                <Label className="text-foreground">Event Name *</Label>
                <Input
                  placeholder="e.g. Summer Music Festival"
                  value={form.title}
                  onChange={(e) => handleChange("title", e.target.value)}
                  className="bg-secondary border-border"
                  required
                  maxLength={100}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-foreground">Description</Label>
                <Textarea
                  placeholder="Tell people what your event is about..."
                  value={form.description}
                  onChange={(e) => handleChange("description", e.target.value)}
                  className="bg-secondary border-border min-h-[100px]"
                  maxLength={1000}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-foreground">Event Type *</Label>
                  <Select value={form.event_type} onValueChange={(v) => handleChange("event_type", v)}>
                    <SelectTrigger className="bg-secondary border-border">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {eventTypes.map((t) => (
                        <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-foreground">Price (₹) *</Label>
                  <Input
                    type="number"
                    placeholder="e.g. 999"
                    value={form.price}
                    onChange={(e) => handleChange("price", e.target.value)}
                    className="bg-secondary border-border"
                    required
                    min="0"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-foreground">Total Tickets *</Label>
                  <Input
                    type="number"
                    placeholder="e.g. 500"
                    value={form.total_tickets}
                    onChange={(e) => handleChange("total_tickets", e.target.value)}
                    className="bg-secondary border-border"
                    required
                    min="1"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-foreground">Date *</Label>
                  <Input
                    type="date"
                    value={form.date}
                    onChange={(e) => handleChange("date", e.target.value)}
                    className="bg-secondary border-border"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-foreground">Time *</Label>
                  <Input
                    placeholder="e.g. 7:00 PM"
                    value={form.time}
                    onChange={(e) => handleChange("time", e.target.value)}
                    className="bg-secondary border-border"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-foreground">Venue *</Label>
                  <Input
                    placeholder="e.g. Phoenix Arena"
                    value={form.venue}
                    onChange={(e) => handleChange("venue", e.target.value)}
                    className="bg-secondary border-border"
                    required
                    maxLength={200}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-foreground">City *</Label>
                  <Input
                    placeholder="e.g. Mumbai, MH"
                    value={form.city}
                    onChange={(e) => handleChange("city", e.target.value)}
                    className="bg-secondary border-border"
                    required
                    maxLength={100}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-foreground">Image URL (optional)</Label>
                  <Input
                    placeholder="https://..."
                    value={form.image_url}
                    onChange={(e) => handleChange("image_url", e.target.value)}
                    className="bg-secondary border-border"
                  />
                </div>
              </div>
            </div>

            <Button type="submit" size="lg" className="w-full glow-primary" disabled={loading}>
              {loading ? "Creating..." : "Create Event"}
            </Button>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CreateEvent;
