import { useParams, Link, useNavigate } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  CalendarDays, MapPin, Clock, Users, ArrowLeft, Ticket,
} from "lucide-react";
import { format } from "date-fns";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import type { Tables } from "@/integrations/supabase/types";

const EventDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [event, setEvent] = useState<Tables<"events"> | null>(null);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const [booking, setBooking] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      if (!id) return;
      const { data, error } = await supabase
        .from("events")
        .select("*")
        .eq("id", id)
        .single();
      if (!error && data) setEvent(data);
      setLoading(false);
    };
    fetch();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-2xl font-bold text-foreground mb-4">
            Event not found
          </h1>
          <Button asChild>
            <Link to="/home">Back to Events</Link>
          </Button>
        </div>
      </div>
    );
  }

  const availability = event.total_tickets > 0
    ? Math.round((event.available_tickets / event.total_tickets) * 100)
    : 0;

  const fallbackImage = "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800&q=80";

  const handleBook = async () => {
    if (!user) {
      navigate("/");
      return;
    }
    if (event.available_tickets < qty) {
      toast.error("Not enough tickets available!");
      return;
    }

    setBooking(true);
    const totalAmount = qty * event.price * 1.05;

    // Create booking
    const { error } = await supabase.from("bookings").insert({
      user_id: user.id,
      event_id: event.id,
      quantity: qty,
      total_amount: totalAmount,
      status: "confirmed",
    });

    if (error) {
      toast.error("Booking failed: " + error.message);
    } else {
      // Decrease available tickets
      await supabase
        .from("events")
        .update({ available_tickets: event.available_tickets - qty })
        .eq("id", event.id);

      toast.success(`${qty} ticket(s) booked for ${event.title}!`, {
        description: `Total: ₹${totalAmount.toFixed(2)}. Payment integration coming soon!`,
      });
      setEvent({ ...event, available_tickets: event.available_tickets - qty });
    }
    setBooking(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-20 pb-20">
        <div className="relative h-[40vh] sm:h-[50vh] overflow-hidden">
          <img
            src={event.image_url || fallbackImage}
            alt={event.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        </div>

        <div className="container -mt-24 relative z-10">
          <Link
            to="/home"
            className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-4 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" /> Back to Events
          </Link>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div>
                <Badge className="mb-3 bg-primary/20 text-primary border-0">
                  {event.event_type}
                </Badge>
                <h1 className="font-display text-4xl font-bold text-foreground">
                  {event.title}
                </h1>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { icon: CalendarDays, label: "Date", value: format(new Date(event.date), "MMM d, yyyy") },
                  { icon: Clock, label: "Time", value: event.time },
                  { icon: MapPin, label: "Venue", value: event.venue },
                  { icon: Users, label: "Available", value: `${event.available_tickets} / ${event.total_tickets}` },
                ].map((item) => (
                  <div key={item.label} className="rounded-lg bg-secondary p-4 space-y-1">
                    <item.icon className="h-5 w-5 text-primary" />
                    <p className="text-xs text-muted-foreground">{item.label}</p>
                    <p className="font-display font-semibold text-foreground text-sm">{item.value}</p>
                  </div>
                ))}
              </div>

              <div>
                <h2 className="font-display text-xl font-semibold text-foreground mb-3">
                  About This Event
                </h2>
                <p className="text-muted-foreground leading-relaxed">
                  {event.description || "No description provided."}
                </p>
              </div>

              {/* Check Availability */}
              <div className="rounded-lg bg-secondary p-6 space-y-3">
                <h3 className="font-display text-lg font-semibold text-foreground">
                  Check Availability
                </h3>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="w-full bg-muted rounded-full h-3">
                      <div
                        className="bg-primary h-3 rounded-full transition-all"
                        style={{ width: `${100 - availability}%` }}
                      />
                    </div>
                  </div>
                  <span className="text-sm font-medium text-foreground whitespace-nowrap">
                    {event.available_tickets} tickets left
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {event.available_tickets <= 0
                    ? "This event is sold out!"
                    : availability < 20
                    ? "Hurry! Almost sold out — book now before it's too late."
                    : "Tickets are available. Secure your spot today!"}
                </p>
              </div>
            </div>

            {/* Booking card */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 rounded-lg bg-card border border-border p-6 space-y-6 card-shadow">
                <div>
                  <p className="text-sm text-muted-foreground">Price per ticket</p>
                  <p className="font-display text-3xl font-bold text-foreground">
                    ₹{event.price}
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">Quantity</label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setQty(Math.max(1, qty - 1))}
                      className="h-10 w-10 rounded-lg bg-secondary text-foreground flex items-center justify-center hover:bg-primary/20 transition-colors"
                    >
                      -
                    </button>
                    <span className="font-display text-lg font-semibold text-foreground w-8 text-center">
                      {qty}
                    </span>
                    <button
                      onClick={() => setQty(Math.min(10, qty + 1))}
                      className="h-10 w-10 rounded-lg bg-secondary text-foreground flex items-center justify-center hover:bg-primary/20 transition-colors"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="border-t border-border pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{qty} × ₹{event.price}</span>
                    <span className="text-foreground font-medium">₹{qty * event.price}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Service fee</span>
                    <span className="text-foreground font-medium">₹{(qty * event.price * 0.05).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-display font-bold text-lg pt-2 border-t border-border">
                    <span className="text-foreground">Total</span>
                    <span className="text-primary">₹{(qty * event.price * 1.05).toFixed(2)}</span>
                  </div>
                </div>

                <Button
                  onClick={handleBook}
                  className="w-full glow-primary animate-pulse-glow"
                  size="lg"
                  disabled={booking || event.available_tickets <= 0}
                >
                  <Ticket className="mr-2 h-5 w-5" />
                  {event.available_tickets <= 0 ? "Sold Out" : booking ? "Booking..." : "Book Now"}
                </Button>

                <p className="text-xs text-center text-muted-foreground">
                  Secure checkout · Instant confirmation
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default EventDetail;
