import { Link } from "react-router-dom";
import { CalendarDays, MapPin, Tag } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import type { Tables } from "@/integrations/supabase/types";

interface EventCardProps {
  event: Tables<"events">;
}

const categoryColors: Record<string, string> = {
  concert: "bg-primary/20 text-primary",
  conference: "bg-accent/20 text-accent",
  sports: "bg-green-500/20 text-green-400",
  theater: "bg-purple-500/20 text-purple-400",
  festival: "bg-pink-500/20 text-pink-400",
  workshop: "bg-blue-500/20 text-blue-400",
};

const EventCard = ({ event }: EventCardProps) => {
  const availability = event.total_tickets > 0
    ? Math.round((event.available_tickets / event.total_tickets) * 100)
    : 0;

  const fallbackImage = "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800&q=80";

  return (
    <Link
      to={`/events/${event.id}`}
      className="group block rounded-lg overflow-hidden bg-card border border-border hover:border-primary/40 transition-all duration-300 card-shadow hover:glow-primary"
    >
      <div className="relative aspect-[16/10] overflow-hidden">
        <img
          src={event.image_url || fallbackImage}
          alt={event.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
        <Badge
          className={`absolute top-3 left-3 border-0 ${
            categoryColors[event.event_type] || "bg-primary/20 text-primary"
          }`}
        >
          {event.event_type}
        </Badge>
      </div>

      <div className="p-5 space-y-3">
        <h3 className="font-display text-lg font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-1">
          {event.title}
        </h3>

        <div className="space-y-2 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-primary/70" />
            <span>
              {format(new Date(event.date), "MMM d, yyyy")} · {event.time}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-primary/70" />
            <span>{event.venue}, {event.city}</span>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-border">
          <div className="flex items-center gap-1">
            <Tag className="h-4 w-4 text-primary" />
            <span className="font-display font-bold text-foreground">
              ₹{event.price}
            </span>
          </div>
          <span
            className={`text-xs font-medium ${
              availability < 20 ? "text-destructive" : "text-muted-foreground"
            }`}
          >
            {event.available_tickets <= 0
              ? "Sold Out"
              : availability < 20
              ? "Almost Sold Out"
              : `${event.available_tickets} left`}
          </span>
        </div>
      </div>
    </Link>
  );
};

export default EventCard;
